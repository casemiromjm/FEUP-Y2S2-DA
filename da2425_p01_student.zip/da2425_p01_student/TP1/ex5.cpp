#include "../data_structures/Graph.h"
#include "stack"
using namespace std;

template <typename T>
vector<vector<T>> sccTarjan(Graph<T>* g) {
    vector<vector<T>> res;
    // TODO
    return res;
}