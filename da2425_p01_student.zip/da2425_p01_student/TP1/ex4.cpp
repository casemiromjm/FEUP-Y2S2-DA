#include "../data_structures/Graph.h"
#include "stack"
using namespace std;

// Kosaraju-Sharir algorithm
template <typename T>
vector<vector<T>> SCCkosaraju(Graph<T>* g)  {
    vector<vector<T>> sccs;
    // TODO
    return sccs;
}



